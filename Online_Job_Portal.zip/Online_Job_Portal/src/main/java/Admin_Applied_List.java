

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Servlet implementation class Admin_Applied_List
 */
public class Admin_Applied_List extends HttpServlet {
	
	
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String today = df.format(date);
		
		String resume = req.getParameter("resume");
		String application_id = req.getParameter("application_id");  
		String event = req.getParameter("submit");
		
		 
		
		if(event.equals("Accept"))
		{
			if(application_id.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Applied_List.jsp';  </script> ");
			}
			else
			{
				try
				{

					String sql = "update candidate_applications set status = 'Accepted' where application_id = '"+application_id+"'";
					String update = db.update(sql);
					out.println(update);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Application Accepted Successfully..!'); location='Admin_Applied_List.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Applied_List.jsp';  </script> ");
				}
			}
		}
		
		
		if(event.equals("Reject"))
		{
			if(application_id.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Applied_List.jsp';  </script> ");
			}
			else
			{
				try
				{

					String sql = "update candidate_applications set status = 'Rejected' where application_id = '"+application_id+"'";
					String update = db.update(sql);
					out.println(update);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Application Rejected Successfully..!'); location='Admin_Applied_List.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Applied_List.jsp';  </script> ");
				}
			}
		}
		
		if(event.equals("Download"))
		{
			if(resume.equals("") )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Resume not available to download'); location='Candidate_Profile.jsp';  </script> ");
			}
			else
			{
				try
				{

					resp.setContentType("APPLICATION/OCTET-STREAM");   
					resp.setHeader("Content-Disposition","attachment; filename=\"" + resume + "\"");   
					  
					FileInputStream fileInputStream = new FileInputStream("resumes" + resume);  
					            
					int i;   
					while ((i=fileInputStream.read()) != -1) {  
					out.write(i);   
					}   
					fileInputStream.close();   
					out.close();   
					 
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Profile.jsp';  </script> ");
				}
			}
		}
	}

}
