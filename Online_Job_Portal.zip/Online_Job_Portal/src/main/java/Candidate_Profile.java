

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Servlet implementation class Candidate_Profile
 */
public class Candidate_Profile extends HttpServlet {
	
	
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String today = df.format(date);
		
		
		String image = req.getParameter("image");
		String resume = req.getParameter("resume");
		String resume1 = req.getParameter("resume1");
		
		
		String event = req.getParameter("submit");
		
		 
		
		if(event.equals("Update Profile"))
		{
			if(image.equals("") || resume.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Candidate_Profile.jsp';  </script> ");
			}
			else
			{
				try
				{

					String sql = "update candidate_signup set image = '"+image+"', resume = '"+resume+"' where candidate_id = '"+session.getAttribute("candidate_id")+"'";
					String update = db.update(sql);
					out.println(update);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Profile Updated Successfully..!'); location='Candidate_Profile.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Profile.jsp';  </script> ");
				}
			}
		}
		
		if(event.equals("Download"))
		{
			if(resume1.equals("") )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Resume not available to download'); location='Candidate_Profile.jsp';  </script> ");
			}
			else
			{
				try
				{

					resp.setContentType("APPLICATION/OCTET-STREAM");   
					resp.setHeader("Content-Disposition","attachment; filename=\"" + resume1 + "\"");   
					  
					FileInputStream fileInputStream = new FileInputStream("resumes" + resume1);  
					            
					int i;   
					while ((i=fileInputStream.read()) != -1) {  
					out.write(i);   
					}   
					fileInputStream.close();   
					out.close();   
					 
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Profile.jsp';  </script> ");
				}
			}
		}
		  
	}

}
