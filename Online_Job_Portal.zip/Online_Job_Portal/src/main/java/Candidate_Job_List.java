

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class Candidate_Job_List
 */
public class Candidate_Job_List extends HttpServlet {


	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		
		String job_id = req.getParameter("job_id");
		String event = req.getParameter("submit");
		
		
		out.println(job_id);
		out.println(event);
		
		
		if(event.equals("View Details"))
		{
			if(job_id.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Candidate_Job_List.jsp';  </script> ");
			}
			else
			{
				try
				{

					session.setAttribute("job_id", job_id);
					resp.sendRedirect("Candidate_Job_Details.jsp");
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Job_List.jsp';  </script> ");
				}
			}
		}
	}

}
