

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class Admin_Add_Job
 */
public class Admin_Add_Job extends HttpServlet {
	 
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		String job_id = req.getParameter("job_id");
		String job_tital = req.getParameter("job_tital");
		String company_name = req.getParameter("company_name");
		String shift = req.getParameter("shift");
		String experiance = req.getParameter("experiance");
		String salary = req.getParameter("salary");
		String job_description = req.getParameter("job_description");
		String logo = req.getParameter("logo"); 
		
		String event = req.getParameter("submit");
		
		 
		
		
		if(event.equals("ADD"))
		{
			if(job_tital.equals("") || company_name.equals("") || shift.equals("") || experiance.equals("") || salary.equals("") || job_description.equals("") ||  logo.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Add_Job.jsp';  </script> ");
			}
			else
			{
				try
				{
					String sql = "insert into admin_add_job (job_tital, company_name, shift, experiance, salary, job_description, logo ) values ('"+job_tital+"', '"+company_name+"', '"+shift+"','"+experiance+"', '"+salary+"', '"+job_description+"', '"+logo+"'); ";
					String insert = db.Insert(sql);
					out.println(insert);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Job Added'); location='Admin_Add_Job.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Add_Job.jsp';  </script> ");
				}
			}
		}
		
		if(event.equals("UPDATE"))
		{
			if(company_name.equals("") || shift.equals("") || experiance.equals("") || salary.equals("") || job_description.equals("") || logo.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\">alert('Some Fields are Empty');location='Admin_Add_Job.jsp';</script>");
			}
			else
			{
				try
				{
					String sql = "update admin_add_job set  company_name = '"+company_name+"', shift='"+shift+"', experiance='"+experiance+"', salary = '"+salary+"', job_description='"+job_description+"', logo = '"+logo+"' where job_tital ='"+job_tital+"' ";
					String update = db.update(sql);
					out.println(update);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\">alert('job Updated');location='Admin_Add_Job.jsp';</script>");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"');location='Admin_Add_Job.jsp';</script>");
				}
			}
		}
		if(event.equals("DELETE"))
		{
			if(job_id.equals("")  )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Add_Job.jsp';  </script> ");
			}
			else
			{
				try
				{
					String sql = " delete from admin_add_job where job_id = '"+job_id+"'";
					String delete = db.delete(sql);
					out.println(delete);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Job Deleted'); location='Admin_Add_Job.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Add_Job.jsp';  </script> ");
				}
			}
		}
		



		
		
	}
}

		
		
		