

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Servlet implementation class Candidate_Job_Details
 */
public class Candidate_Job_Details extends HttpServlet {
	
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		String today = df.format(date);
		
		
		String job_id = req.getParameter("job_id");
		String job_tital = req.getParameter("job_tital");
		String company_name = req.getParameter("company_name");
		String shift = req.getParameter("shift");
		String experiance = req.getParameter("experiance");
		String salary = req.getParameter("salary");
		String job_description = req.getParameter("job_description");
		String logo = req.getParameter("logo");
		
		String candidate_id = session.getAttribute("candidate_id").toString();
		String first_name = session.getAttribute("first_name").toString();
		String last_name = session.getAttribute("last_name").toString();
		String email = session.getAttribute("email").toString();
		String phone = session.getAttribute("phone").toString();
		String username = session.getAttribute("username").toString();
		
		String event = req.getParameter("submit");
		
		
		out.println(job_id);
		out.println(job_tital);
		out.println(company_name);
		out.println(shift);
		out.println(experiance);
		out.println(salary);
		out.println(job_description);
		out.println(logo);
		out.println(event);
		out.println(candidate_id);
		out.println(first_name);
		out.println(last_name);
		out.println(email);
		out.println(phone);
		out.println(username);
		
		
		if(event.equals("Apply"))
		{
			if(job_id.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Candidate_Job_Details.jsp';  </script> ");
			}
			else
			{
				try
				{

					String sql = "insert into candidate_applications (candidate_id,first_name, last_name, email, phone, username,job_id,job_tital, company_name, shift, experiance, salary, job_description, logo, applied_date, status, resume ) values ('"+candidate_id+"','"+first_name+"', '"+last_name+"', '"+email+"','"+phone+"', '"+username+"','"+job_id+"','"+job_tital+"', '"+company_name+"', '"+shift+"','"+experiance+"', '"+salary+"', '"+job_description+"', '"+logo+"','"+today+"', 'Pending','"+session.getAttribute("resume")+"'); ";
					String insert = db.Insert(sql);
					out.println(insert);
					
					resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Application Submitted Successfully..!'); location='Candidate_Job_Details.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Job_Details.jsp';  </script> ");
				}
			}
		}
	}

}
