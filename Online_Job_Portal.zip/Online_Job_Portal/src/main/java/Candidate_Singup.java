

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class Candidate_Singup
 */
public class Candidate_Singup extends HttpServlet {
	
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		
		String first_name = req.getParameter("first_name");
		String last_name = req.getParameter("last_name");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String event = req.getParameter("submit");
		
		
		out.println(first_name);
		out.println(last_name);
		out.println(email);
		out.println(phone);
		out.println(username);
		out.println(password); 
		out.println(event);
		
		
		if(event.equals("Submit"))
		{
			if(first_name.equals("") || last_name.equals("") || email.equals("") || phone.equals("") || username.equals("") || password.equals("") )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Candidate_Signup.jsp';  </script> ");
			}
			else
			{
				try
				{
					String sql = "insert into candidate_signup (first_name, last_name, email, phone, username, password) values ('"+first_name+"', '"+last_name+"', '"+email+"','"+phone+"', '"+username+"', '"+password+"'); ";
					String insert = db.Insert(sql);
					out.println(insert);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Signup Successfull'); location='Candidate_Login.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Signup.jsp';  </script> ");
				}
			}
		}
		
		
		
		
	}

}
