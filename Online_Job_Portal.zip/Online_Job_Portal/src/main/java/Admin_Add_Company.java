

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

 

/**
 * Servlet implementation class Admin_Add_Company
 */
public class Admin_Add_Company extends HttpServlet {
	 
	
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		
		String company_id = req.getParameter("company_id");
		String company_name = req.getParameter("company_name");
		String company_type = req.getParameter("company_type");
		String industry = req.getParameter("industry");
		String city = req.getParameter("city");
		String founded = req.getParameter("founded");
		String company_size = req.getParameter("company_size");
		String website = req.getParameter("website");
		String logo = req.getParameter("logo");
		
		String event = req.getParameter("submit");
		
		 
		
		
		if(event.equals("ADD"))
		{
			if(company_name.equals("") || company_type.equals("") || industry.equals("") || city.equals("") || founded.equals("") || company_size.equals("") || website.equals("") || logo.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Add_Company.jsp';  </script> ");
			}
			else
			{
				try
				{
					String sql = "insert into admin_add_company (company_name, company_type, industry, city, founded, company_size, website, logo) values ('"+company_name+"', '"+company_type+"', '"+industry+"','"+city+"', '"+founded+"', '"+company_size+"', '"+website+"', '"+logo+"'); ";
					String insert = db.Insert(sql);
					out.println(insert);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Company Added'); location='Admin_Add_Company.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Add_Company.jsp';  </script> ");
				}
			}
		}
		
		
		if(event.equals("UPDATE"))
		{
			if(company_name.equals("") || company_type.equals("") || industry.equals("") || city.equals("") || founded.equals("") || company_size.equals("") || website.equals("") || logo.equals(""))
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Add_Company.jsp';  </script> ");
			}
			else
			{
				try
				{
					String sql = "update admin_add_company set company_name = '"+company_name+"', company_type = '"+company_type+"', industry='"+industry+"', city='"+city+"', founded = '"+founded+"', company_size='"+company_size+"', website='"+website+"', logo = '"+logo+"' where company_id ='"+company_id+"' ";
					String update = db.update(sql);
					out.println(update);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Company Updated'); location='Admin_Add_Company.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Add_Company.jsp';  </script> ");
				}
			}
		}
		
		
		
		if(event.equals("DELETE"))
		{
			if(company_id.equals("")  )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Add_Company.jsp';  </script> ");
			}
			else
			{
				try
				{
					String sql = " delete from admin_add_company where company_id = '"+company_id+"'";
					String delete = db.delete(sql);
					out.println(delete);
					
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Company Deleted'); location='Admin_Add_Company.jsp';  </script> ");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Add_Company.jsp';  </script> ");
				}
			}
		}
		
		 
		
		
		
		
	}

}