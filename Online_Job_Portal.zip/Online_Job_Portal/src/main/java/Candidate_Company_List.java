

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class Candidate_Company_List
 */
public class Candidate_Company_List extends HttpServlet {

	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		
		String company_name = req.getParameter("company_name"); 
		
		String event = req.getParameter("submit");
		
		 
		
		
		if(event.equals("View Jobs"))
		{
			if(company_name.equals("") )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Candidate_Company_List.jsp';  </script> ");
			}
			else
			{
				try
				{
					session.setAttribute("company_name", company_name); 
					resp.sendRedirect("candidate_job_bycompanies.jsp");
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Candidate_Company_List.jsp';  </script> ");
				}
			}
		}
		
		
		
		
	}

}