

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Servlet implementation class Admin_Login
 */
public class Admin_Login extends HttpServlet {
	 
	Connection cn = null;
	Statement st = null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();
		HttpSession session = req.getSession();
		
		Database db = new Database();
		String result = db.Connectdb();
		out.println(result);
		
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String event = req.getParameter("submit");
		
		out.println(username);
		out.println(password);
		out.println(event);
		
		
		if(event.equals("Submit"))
		{
			if(username.equals("") || password.equals("") )
			{
				resp.setContentType("text/html");
				out.println(" <script type=\"text/javascript\"> alert('Some Fields are Empty'); location='Admin_Login.jsp';  </script> ");
			}
			else
			{
				try
				{
					  Class.forName("com.mysql.jdbc.Driver");
		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_job_portal","root","root");
		              st=cn.createStatement();
		              String sql = "select * from admin_signup where username ='"+username+"' && password='"+password+"' ";
		              ResultSet rs=st.executeQuery(sql);
		              if(rs.next())
		              { 
		            	  resp.setContentType("text/html");
		            	  out.println(" <script type=\"text/javascript\"> alert('Login Successfull'); location='Admin_Home.jsp';  </script> ");
		              }
		              else
		              {
		            	  resp.setContentType("text/html");
						  out.println(" <script type=\"text/javascript\"> alert('Wrong username or Password'); location='Admin_Login.jsp';  </script> ");
		              }
					
					
					
				}
				catch(Exception ex)
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='Admin_Login.jsp';  </script> ");
				}
			}
		}
		
	}
}
