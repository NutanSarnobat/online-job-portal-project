create database Online_Job_Portal;
use Online_Job_Portal;


create table admin_signup
(
	admin_id int auto_increment primary key,
    first_name nvarchar(50),admin_add_job
    last_name nvarchar(50),
    email nvarchar(50),
    phone bigint(10),
    username nvarchar(50),
    password nvarchar(50) 
);

create table admin_add_company
(
	company_id int auto_increment primary key,
    company_name nvarchar(500),
    company_type nvarchar(50),
    industry nvarchar(50),
    city nvarchar(50),
    founded nvarchar(50),
    company_size nvarchar(50),
    website nvarchar(50),
    logo nvarchar(500)
);

create table admin_add_job
(
	job_id int auto_increment primary key,
    job_tital nvarchar(50),
    company_name nvarchar(50),
    shift nvarchar(50),
    experiance nvarchar(50),
    salary nvarchar(50),
    job_description nvarchar(1000),
    logo nvarchar(500)
);

create table candidate_signup
(
	candidate_id int auto_increment primary key,
    first_name nvarchar(50),
    last_name nvarchar(50),
    email nvarchar(50),
    phone bigint(10),
    username nvarchar(50),
    password nvarchar(50) 
);

create table candidate_applications
(
	application_id int auto_increment primary key,
	candidate_id int,
	first_name nvarchar(50),
	last_name nvarchar(50),
	email nvarchar(50),
	phone bigint(10),
	username nvarchar(50),
	job_id int,
	job_tital nvarchar(50),
	company_name nvarchar(50),
	shift nvarchar(50),
	experiance nvarchar(50),
	salary nvarchar(50),
	job_description nvarchar(1000),
	logo nvarchar(500),
	applied_date nvarchar(50),
	status nvarchar(50)
);

create table admin_add_product
(
	admin_add_product int auto_increment primary key,
	product_id int,
	product_name nvarchar(500),
	description nvarchar(500),
	image1 nvarchar(2000)
    );
	